// ============================================================
// LIVRABLE 6b — DASHBOARD PAGE PATCH
// Fichier cible : app/[locale]/dashboard/page.tsx
// ============================================================

// ── ÉTAPE 1 : Importer calculateComplianceItems ──────────────
// Ajouter en haut du fichier :
//
// import { calculateComplianceItems } from '@/lib/compliance/calculateComplianceItems'
// import ComplianceItemCard from '@/components/compliance/ComplianceItemCard'
// import Link from 'next/link'


// ── ÉTAPE 2 : Appeler le moteur dans le Server Component ─────
// Dans la fonction composant, après avoir récupéré company :
/*
const complianceResult = company
  ? await calculateComplianceItems(company.id, supabase)
  : null

const urgentItems = complianceResult?.items.filter(i => i.status === 'required').slice(0, 2) ?? []
*/


// ── ÉTAPE 3 : Carte stat 1 "Taux de conformité" ─────────────
// Trouve la carte stat avec le taux de conformité (valeur mockée style "75%")
// et remplace sa valeur par :
/*
  {complianceResult ? `${complianceResult.percentage}%` : '—'}
*/


// ── ÉTAPE 4 : Carte stat 3 "Actions requises" ───────────────
// Trouve la carte stat des actions requises et remplace par :
/*
<Link href={`/${locale}/dashboard/compliance`} className="block">
  <div className="... (garder les classes existantes)">
    <span className="... valeur">{complianceResult?.urgentCount ?? 0}</span>
    {(complianceResult?.urgentCount ?? 0) > 0 && (
      <span
        className="ml-2 text-[10px] font-bold px-1.5 py-0.5 rounded-full"
        style={{ backgroundColor: '#C9A5A5', color: '#6B1E1E' }}
      >
        !
      </span>
    )}
    <p className="... label">Actions requises</p>
  </div>
</Link>
*/


// ── ÉTAPE 5 : Widget Urgences (NOUVEAU bloc) ─────────────────
// Ajouter CE BLOC en bas du dashboard, juste avant la fermeture </div> principale,
// UNIQUEMENT si urgentItems.length > 0 :
/*
{urgentItems.length > 0 && (
  <section className="mt-8">
    <div className="flex items-center justify-between mb-3">
      <h2
        className="text-sm font-bold uppercase tracking-wider"
        style={{
          fontFamily: "'Sora', sans-serif",
          color: '#6B1E1E',
          letterSpacing: '0.08em',
        }}
      >
        ⚡ {locale === 'fr' ? 'Actions urgentes' : 'Urgent actions'}
      </h2>
      <Link
        href={`/${locale}/dashboard/compliance`}
        className="text-xs font-semibold underline-offset-2 underline"
        style={{ color: '#4A6B93' }}
      >
        {locale === 'fr' ? 'Voir tout →' : 'View all →'}
      </Link>
    </div>
    <div className="flex flex-col gap-3">
      {urgentItems.map(item => (
        <ComplianceItemCard
          key={item.id}
          item={item}
          locale={locale as 'fr' | 'en'}
        />
      ))}
    </div>
  </section>
)}
*/
