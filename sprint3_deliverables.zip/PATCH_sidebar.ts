// ============================================================
// LIVRABLE 6a — SIDEBAR PATCH
// Fichier cible : components/layout/Sidebar.tsx (ou similaire)
// 
// Ce fichier montre les CHANGEMENTS EXACTS à appliquer.
// Cherche les patterns ci-dessous et applique les diffs.
// ============================================================

// ── ÉTAPE 1 : Ajouter l'import ShieldCheck ──────────────────
// Trouve la ligne d'import lucide-react et ajoute ShieldCheck :
//
// AVANT :
//   import { FileText, Home, /* ... autres icônes */ } from 'lucide-react'
//
// APRÈS :
//   import { FileText, Home, ShieldCheck, /* ... autres icônes */ } from 'lucide-react'


// ── ÉTAPE 2 : Ajouter le lien "Conformité" dans la nav ───────
// Trouve le bloc de navigation. Ajoute ENTRE "Tableau de bord" et "Documents".
//
// Modèle du lien existant "Tableau de bord" (pour référence) :
// <Link href={`/${locale}/dashboard`} className={...}>
//   <Home size={18} />
//   <span>Tableau de bord</span>
// </Link>
//
// ── INSÉRER CE BLOC après "Tableau de bord" et avant "Documents" :

/*
<Link
  href={`/${locale}/dashboard/compliance`}
  className={[
    'flex items-center gap-3 px-4 py-2.5 rounded-lg text-sm font-medium transition-colors',
    isActive('/dashboard/compliance')
      ? 'text-[#F5B91E] bg-white/10'
      : 'text-white/70 hover:text-white hover:bg-white/5',
  ].join(' ')}
>
  <ShieldCheck size={18} />
  <span className="flex-1">
    {locale === 'fr' ? 'Conformité' : 'Compliance'}
  </span>
  {urgentCount > 0 && (
    <span
      className="flex-shrink-0 text-[10px] font-bold px-1.5 py-0.5 rounded-full min-w-[20px] text-center"
      style={{ backgroundColor: '#C9A5A5', color: '#6B1E1E' }}
    >
      {urgentCount}
    </span>
  )}
</Link>
*/

// ── ÉTAPE 3 : Recevoir urgentCount en prop ───────────────────
// Si la sidebar est un Server Component :
//   → Calculer urgentCount dans le layout parent et le passer en prop
//
// Si la sidebar est un Client Component :
//   → Ajouter urgentCount?: number dans les props de la sidebar
//
// Interface props à modifier :
/*
interface SidebarProps {
  locale: string
  // ... props existantes ...
  urgentCount?: number  // ← AJOUTER
}
*/

// ── ÉTAPE 4 : Passer urgentCount depuis le layout ────────────
// Dans app/[locale]/dashboard/layout.tsx :
/*
import { calculateComplianceItems } from '@/lib/compliance/calculateComplianceItems'

// Dans le composant layout, APRÈS avoir récupéré company :
const complianceResult = company
  ? await calculateComplianceItems(company.id, supabase)
  : null
const urgentCount = complianceResult?.urgentCount ?? 0

// Puis passer à la sidebar :
<Sidebar locale={locale} urgentCount={urgentCount} />
*/
